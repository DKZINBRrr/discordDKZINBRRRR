import logging
import ujson
from telegram import Bot
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackQueryHandler, ConversationHandler, CallbackContext

class start:
    commands = ["start",
                         "menu",
                         "cpf",
                         "cns",
                         "nome",
                         "telefone"]
    admin_commands = ["add", "discount", "remove", "removecaptcha", "addblocklist", "removeblocklist", "addadmin", "removeadmin"]          
              
    def __init__(self, token, callback, main):
        logging.basicConfig(
          format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
          level = logging.INFO
         )
         
        self.updater = Updater(token)
        self.bot = Bot( token = token )
        self.logger = logging.getLogger(__name__)
        
        self.updater.dispatcher.add_handler(CallbackQueryHandler(callback))
        
        for i in [start.commands, start.admin_commands]:
            for k in i:
                self.updater.dispatcher.add_handler(CommandHandler(k, main))
            
class bot_data:
    path = "database/"
    
    def reload(self):
        path = bot_data.path
        
        files = [
          [self.admin, "%sadmin.json"],
          [self.blocklist, "%sblocklist.json"],
          [self.captcha_list, "%scaptcha_list.json"],
          [self.clientes, "%sclientes.json"]
        ]
        
        for i in files:
            data = i[0] 
            file = i[1] %path
            
            with open(file, "w+") as f:
                f.write(ujson.dumps(data, indent = 4, sort_keys = True))
        
    def _admin(self, key, id, value = None):
        id = str(id)
        
        if ( key == "/add" ) and ( not id in self.clientes):
            self.clientes[id] = value
            message = "**❲ ✅ ❳ - ID adicionado com sucesso na lista de clientes.**"
        
        elif ( key == "/remove" ) and ( id in self.clientes):
            del self.clientes[id]
            message = "**❲ ✅ ❳ - ID adicionado com sucesso da lista de clientes.**"
        
        elif ( key == "/discount" ) and ( id in self.clientes):
            value = (self.clientes[id] - value)
            self.clientes[id] = value
            message = "**❲ ✅ ❳ - Valor descontado com sucesso do ID.**"
        
        elif ( key == "/removecaptcha" ) and (id in self.captcha_list):
            del self.captcha_list[id]
            message = "**❲ ✅ ❳ - ID removido com sucesso do captcha.**"
        
        elif ( key == "/addblocklist" ) and ( not id in self.blocklist):
            self.blocklist.append(id)
            message = "**❲ ✅ ❳ - ID adicionado com sucesso na blocklist.**"
        
        elif ( key == "/removeblocklist" ) and ( id in self.blocklist):
            self.blocklist.remove(id)
            message = "**❲ ✅ ❳ - ID removido com sucesso da blocklist.**"
        
        elif ( key == "/addadmin" ) and ( not id in self.admin):
            self.admin.append(id)
            message = "**❲ ✅ ❳ - ID adicionado com sucesso na lista de admins.**"
        
        elif ( key == "/removeadmin") and ( id in self.admin):
            self.admin.remove(id)
            message = "**❲ ✅ ❳ - ID removido com sucesso da lista de admins.**"
        
        else:
            message = "**❲ ❌ ❳ - Não foi possível realizar esta operação.**"
        
        return message
    
    def __init__(self):
        path = bot_data.path
        
        self.admin_commands = ["/add", "/discount", "/remove", "/removecaptcha", "/addblocklist", "/removeblocklist", "/addadmin", "/removeadmin"]
        
        self.token = open(path + "token.txt", "r").read()
        self.pattern_message = open(path + 'pattern_message.txt', 'r').read()
        self.blocklist_message = open(path + 'blocklist_message.txt', 'r').read()
        self.notadmin_message = open(path + 'notadmin_message.txt', 'r').read()
        
        captcha_message = open(path + 'captcha_message.json', 'r').read()
        
        self.captcha_message = ujson.loads(captcha_message)
        
        admin = open(path + "admin.json", "r").read()
        blocklist = open(path + "blocklist.json", "r").read()
        captcha_list = open(path + "captcha_list.json", "r").read()
        clientes = open(path + "clientes.json", "r").read()
        
        self.admin = ujson.loads(admin)
        self.blocklist = ujson.loads(blocklist)
        self.captcha_list = ujson.loads(captcha_list)
        self.clientes = ujson.loads(clientes)
        self.logo = open(path + "logo.jpg", "rb").read()
        
        self.api_serasa = "http://api.lkzn.tk/api/cpfSimples.php?token=9c06b7c4-627e-4b66-8837-f1b82c2c3854&cpf=%s"
        self.api_esus = "http://api.lkzn.tk/api/esus.php?token=640114c8-25d2-4a04-be16-6b23b2d6ed10&consulta=%s"
        self.api_nome = "https://api.i-find.dev/?token=1c6e8577-b799-4267-bf12-f8bfb704466c&nome=%s"
        self.api_placa_detran = "http://api.i-find.dev/?token=1c6e8577-b799-4267-bf12-f8bfb704466c&detranPlaca=%s"
        self.api_telefone_teldb = "http://api.i-find.dev/?token=1c6e8577-b799-4267-bf12-f8bfb704466c&telDb=%s"
        self.api_cpf_cadsus = "http://api.i-find.dev/?token=1c6e8577-b799-4267-bf12-f8bfb704466c&cpf=%s"