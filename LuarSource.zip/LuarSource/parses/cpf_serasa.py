def parse(message):
    response = "**❲ ✅ ❳ - CPF encontrado!**\n\n"
    response += "**❲ Dados Pessoais ❳**\n\n"
    response += "**CPF ** - ``` %s```\n" %message["cpf"]
    response += "**Nome ** - ``` %s```\n" %message["nome"]
    response += "**Sexo ** - ``` %s```\n" %message["sexo"]
    response += "**Nascimento ** - ``` %s```" %message["nascimento"]
    
    return response