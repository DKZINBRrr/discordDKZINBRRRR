def parse(gn, message):
    
    msg = ""
    for i in message:
        msg += "Nome - %s\n" % i["Nome"]
        msg += "CPF - %s\n" %i["Cpf"]
        msg += "Sexo - %s\n"  %i["Genero"]
        msg += "Nascimento - %s\n\n" %i["Nascimento"]
    
    file = gn(12, delimit = 4, delimit_str = "-") + "-nome.txt"
    
    with open("media/%s" %file, "w+") as f:
        f.write(msg[:-2])
    
    return file