def delete(bot, message_id, chat_id):
    try:
        return bot.bot.delete_message(
        chat_id = int(chat_id),
        message_id = int(message_id))
    except Exception as error:
        print(str(error))
        return False