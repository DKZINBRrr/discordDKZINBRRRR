import random
import simple_funcs.spliter as spliter
import simple_funcs.generator as gn

import requests
import base64
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

class captcha:
    def codeGenerator():
        response = gn.generator(6, strings = "0123456789")
        return response
        
    def generator(code):
        url_1, url_2 = ["https://fakecaptcha.com/generate.php", 
                                "https://fakecaptcha.com/result.php"]
        payload_1 = {"words": code, "force": 0, "color": "red"}
        
        _words = requests.post(url_1, data = payload_1)
        words = spliter.spliter(_words.text, '<input type="hidden" name="words" value="', '"')
        
        payload_2 = {"words": words}
        
        _foto = requests.post(url_2, data = payload_2)
        _foto = spliter.spliter(_foto.text, 'src="data:image/jpg;base64,', '"')
        foto = base64.b64decode(_foto)
        
        return foto
    
    def __init__(self, user_id, message_id):
        codes = []
        for _ in range(6):
            codes.append(captcha.codeGenerator())
        
        self.code = random.choice(codes)
        self.photo = captcha.generator(self.code)
        
        user_id = str(user_id)
        message_id = str(message_id)
        
        code_lists = [
            [InlineKeyboardButton(codes[0], callback_data = "/captcha %s %s %s" %( user_id, message_id, codes[0] ) ), InlineKeyboardButton(codes[1], callback_data = "/captcha %s %s %s" %( user_id, message_id, codes[1] ) )],
            [InlineKeyboardButton(codes[2], callback_data = "/captcha %s %s %s" %( user_id, message_id, codes[2] ) ), InlineKeyboardButton(codes[3], callback_data = "/captcha %s %s %s" %( user_id, message_id, codes[3] ) )],
            [InlineKeyboardButton(codes[4], callback_data = "/captcha %s %s %s" %( user_id, message_id, codes[4] ) ), InlineKeyboardButton(codes[5], callback_data = "/captcha %s %s %s" %( user_id, message_id, codes[5] ) )]
        ]
        
        self.code_lists = InlineKeyboardMarkup(code_lists).to_json()