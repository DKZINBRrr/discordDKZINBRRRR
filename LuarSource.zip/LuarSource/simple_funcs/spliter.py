def spliter(text, start, end):
        _response = text.split(start)[1]
        response = _response.split(end)[0]
        return response