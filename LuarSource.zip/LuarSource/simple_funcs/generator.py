import random

def generator(amount, strings = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", delimit = False, delimit_str = False):
    value = ""
    limit = 0
    
    for _ in range(amount):
        random_str = random.choice(strings)
        value += value.join(random_str)
        limit += 1
        
        if delimit and limit >= delimit:
            value += value.join(delimit_str)
            limit = 0
            
    if (delimit) and len(strings) > delimit:
        value = value[:-1]
    
    return value