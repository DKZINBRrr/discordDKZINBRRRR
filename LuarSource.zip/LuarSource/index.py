from utils import captcha, delete
from parses import cpf_serasa, nome_serasa
from simple_funcs import generator
import __init__

import random
import ujson
import requests
from telegram import InputMediaPhoto, Update, ForceReply,InlineKeyboardButton, InlineKeyboardMarkup

error = "❲ ❌ ❳"
warning = "❲ ⚠️ ❳"
blocked = "❲ 🚫 ❳"
success = "❲ ✅ ❳"

status = {200: success, 500: warning, 403: blocked, 400: error, 402: error}

def callback(update, context):
    query = update.callback_query
    message = query.data
    while message[:1] == " ":
        message = message[:-1]
    
    query.answer()
    
    info = message.split(' ')
    while "" in info:
        info = info[:-1]
    
    key = info[0]
    user_id = info[1]
    message_id = info[2]
    
    try:
        base = info[3]
    except:
        pass
    
    try:
        msg = ""
        for i in info[4:]:
            msg += (i + " ")
        msg = msg[:-1]
    except:
        pass
    
    id = str(query.message.reply_to_message.from_user.id)
    print(id, user_id, info, query.message.chat.id)
    
    if (id == user_id) or (user_id in infos.admin):
        markup_string = "/apagar %s %s"
        markup = [[ InlineKeyboardButton("🗑", callback_data = markup_string % (id, message_id) ) ]]
        reply_markup = InlineKeyboardMarkup(markup)
        
        if key == "/apagar":
            for i in [query.message.message_id, int(message_id)]:
                delete( bot, i, query.message.chat_id )
        
        elif key == "/captcha":
            tentativas = infos.captcha_list[user_id]["tentativas"]
            
            if base == infos.captcha_list[user_id]["answer"]:
                del infos.captcha_list[user_id]
                delete( bot, query.message.message_id, query.message.chat.id )
                bot.bot.send_message(
                    chat_id = query.message.chat.id,
                    reply_to_message_id = int(message_id),
                    text = "**%s - Captcha verificado com sucesso!**" %success,
                    reply_markup = reply_markup.to_json(),
                    parse_mode = "Markdown")
            
            elif tentativas >= 2:
                infos.blocklist.append(user_id)
                del infos.captcha_list[user_id]
                delete( bot, query.message.message_id, query.message.chat.id )
                bot.bot.send_message(
                    chat_id = query.message.chat.id,
                    reply_to_message_id = int(message_id),
                    text = "**%s - Não foi possível verificar o captcha.**" %error,
                    reply_markup = reply_markup.to_json(),
                    parse_mode = "Markdown")
            
            else:
                _captcha = captcha.captcha(user_id, message_id)
                
                infos.captcha_list[user_id]["tentativas"] = (tentativas + 1)
                infos.captcha_list[user_id]["answer"] = _captcha.code
                
                bot.bot.edit_message_media(
                    media = InputMediaPhoto(
                        media = _captcha.photo,
                        caption = "**%s - Resolva o captcha!**" %warning,
                        parse_mode = "Markdown"),
                    chat_id = query.message.chat.id,
                    message_id = query.message.message_id,
                    reply_markup = _captcha.code_lists)
                    
        elif key == "/cpf":
            if base == "serasa":
                _response = requests.get(infos.api_serasa % msg)
                response = ujson.loads(_response.text)
                parse = cpf_serasa.parse
            
            if response["status"] == 200:
                msg = parse(response["msg"])
                
            else:
                msg = "**%s - O CPF não foi encontrado!**" %error
            
            bot.bot.edit_message_text(
                text = msg,
                chat_id = query.message.chat.id,
                message_id = query.message.message_id,
                reply_markup = reply_markup.to_json(),
                parse_mode = "Markdown")
            
        elif key == "/nome":
            if base == "serasa":
                _response = requests.get(infos.api_nome % msg)
                response = ujson.loads(_response.text)
                parse = nome_serasa.parse
            
            if len(response) > 0:
                msg = parse(gn, response)
                
                delete( bot, query.message.message_id, query.message.chat.id )
                bot.bot.send_document(
                    document = open("media/%s" %msg, "r"),
                    caption = "**%s - Nome encontrado com sucesso!**" %success,
                    chat_id = query.message.chat.id,
                    reply_to_message_id = int(message_id),
                    reply_markup = reply_markup.to_json(),
                    parse_mode = "Markdown")
                
            else:
                bot.bot.edit_message_text(
                    text = "**%s - O nome não foi encontrado!**" %error,
                    chat_id = query.message.chat.id,
                    message_id = query.message.message_id,
                    reply_markup = reply_markup.to_json(),
                    parse_mode = "Markdown")
                
        elif key == "/telefone":
            pass
            
        elif key == "/placa":
            pass
        
        return reload()
    
def main(update, context):
    _message = update.message.text
    chat_id = update.message.chat_id
    user_id = update.message.from_user.id
    message_id = update.message.message_id
    first_name = update.message.from_user.first_name
    
    message = _message.split(' ')
    
    key = message[0].replace('@LuarSearchBot', '').replace('@luarsearchbot', '')
    other_message = message[1:]
    
    markup_string = "/apagar %i %i"
    markup = [
                      [ InlineKeyboardButton("🗑", callback_data = markup_string % (user_id, message_id) ) ]
                      ]
    reply_markup = InlineKeyboardMarkup(markup)
    
    if key in ['/menu', '/start']:
        markup = [
            [
            InlineKeyboardButton("Consultas", url = "https://github.com/LuarSearch/LuarSearch/blob/main/consultas/main.md"),
            InlineKeyboardButton("Planos", url = "https://github.com/LuarSearch/LuarSearch/blob/main/planos.md")
            ],
            [
            InlineKeyboardButton("Grupos", url = "https://t.me/luarsearch"),
            InlineKeyboardButton("Criador", url = "https://t.me/k_iny")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(markup)
        
        return bot.bot.send_photo(
            chat_id = chat_id,
            photo = infos.logo,
            caption = "Seja bem-vindo(a) ao menu, %s\n❲ ID - %i | Chat ID - %i ❳" %(first_name, user_id, chat_id),
            reply_to_message_id = message_id,
            reply_markup = reply_markup.to_json())
            
    elif str(user_id) in infos.blocklist:
        return bot.bot.send_message(
            text = infos.blocklist_message,
            chat_id = chat_id,
            reply_to_message_id = message_id,
            reply_markup = reply_markup.to_json())
            
    elif str(user_id) in infos.captcha_list:
        return bot.bot.send_message(
            text = infos.captcha_message[0],
            chat_id = chat_id,
            reply_to_message_id = message_id,
            reply_markup = reply_markup.to_json())
        
    elif ( key in infos.admin_commands and str(user_id) in infos.admin ):
        _id = message[1]
        if key in ["/add", "/discount"]:
            value = int(message[2])
            retorno = admin(key, _id, value = value) 
        else:
            retorno = admin(key, _id)
            
        return [reload(), bot.bot.send_message(
                text = retorno,
                chat_id = chat_id,
                reply_to_message_id = message_id,
                reply_markup = reply_markup.to_json())]
            
    elif ( str(chat_id) in infos.clientes and infos.clientes[str(chat_id)] > 0) or (str(user_id) in infos.admin ):
        _captcha = False
        
        if len(other_message) == 0:
            return bot.bot.send_message(
                text = "**%s - Alguns parâmetros estão faltando!**" %error,
                chat_id = chat_id,
                reply_to_message_id = message_id,
                reply_markup = reply_markup.to_json(),
                parse_mode = "Markdown")
                
        elif ( str(user_id) not in infos.admin ) and ( random.choice(range(0, 100)) %3 ):
            _captcha = captcha.captcha(user_id, message_id)
            
        try:
            msg = ""
            for i in other_message:
                msg += (i + " ")
        except:
            pass
        
        if _captcha:
            infos.captcha_list[str(user_id)] = {
                "chat_id": chat_id,
                "tentativas": 0,
                "answer": _captcha.code}
            
            return [reload(), bot.bot.send_photo(
                photo = _captcha.photo,
                chat_id = chat_id,
                reply_to_message_id = message_id,
                caption = "**%s - Resolva o captcha!**" %warning,
                reply_markup = _captcha.code_lists,
                parse_mode = "Markdown")]
            
        elif key == "/cpf":
            markup_string = "%i %i" %(user_id, message_id)
            markup = [
                      [ InlineKeyboardButton("Serasa", callback_data = "/cpf %s serasa %s" %(markup_string, msg) ), InlineKeyboardButton("CADSUS", callback_data = "/cpf %s cadsus %s" %(markup_string, msg) ) ],
                      [InlineKeyboardButton("🗑", callback_data = "/apagar %s" %markup_string)]
                      ]
            reply_markup = InlineKeyboardMarkup(markup)
        
        elif key == "/nome":
            markup_string = "%i %i" %(user_id, message_id)
            markup = [
                      [InlineKeyboardButton("Serasa", callback_data = "/nome %s serasa %s" %(markup_string, msg) )],
                      [InlineKeyboardButton("🗑", callback_data = "/apagar %s" %markup_string)]
                      ]
            reply_markup = InlineKeyboardMarkup(markup)
        
        if str(user_id) not in infos.admin:
            cliente = infos.clientes[str(chat_id)]
            infos.clientes[str(chat_id)] = (cliente - 1)
            
        return [reload(), bot.bot.send_message(
                        text = "**❲ 🔎 ❳ - Selecione o módulo abaixo para realizar a consulta:**",
                        chat_id = chat_id,
                        reply_to_message_id = message_id,
                        reply_markup = reply_markup.to_json(),
                        parse_mode = "Markdown")]
        
    elif not (str(chat_id) in infos.clientes):
        return bot.bot.send_message(
            text = "**%s - Você precisa adquirir um plano!**" %warning,
            chat_id = chat_id,
            reply_to_message_id = message_id,
            reply_markup = reply_markup.to_json(),
            parse_mode = "Markdown")

infos = __init__.bot_data()
bot = __init__.start(infos.token, callback, main)

admin = infos._admin
delete = delete.delete
reload = infos.reload

gn = generator.generator
    
bot.updater.start_polling()
bot.updater.idle()