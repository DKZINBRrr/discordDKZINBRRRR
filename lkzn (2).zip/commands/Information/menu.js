const {
  MessageEmbed
} = require("discord.js");
const config = require("../../botconfig/config.json");
var ee = require("../../botconfig/embed.json");
const settings = require("../../botconfig/settings.json");
module.exports = {
  name: "menu", //the command name for execution & for helpcmd [OPTIONAL]
  category: "Information", //the command category for helpcmd [OPTIONAL]
  cooldown: 30, //the command cooldown for execution & for helpcmd [OPTIONAL]
  usage: "menu", //the command usage for helpcmd [OPTIONAL]
  description: "Mostrar todos os comandos", //the command description for helpcmd [OPTIONAL]
  minargs: 0, // minimum args for the message, 0 == none [OPTIONAL]
  maxargs: 0, // maximum args for the message, 0 == none [OPTIONAL]
  minplusargs: 0, // minimum args for the message, splitted with "++" , 0 == none [OPTIONAL]
  maxplusargs: 0, // maximum args for the message, splitted with "++" , 0 == none [OPTIONAL]
  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    try {
      message.reply({embeds: [new MessageEmbed()
        .setColor('#6300ff')
        .setFooter(`LKZN SEARCH - MENU`)
        .setDescription(`Olá, ${message.author.username}\n\nSou o BOT oficial da LKZN BUSCAS\nDesenvolvido para realizar consultas no Discord!\n\n` + '```CONSULTAS DISPONIVEIS:\n/nome teste\n/tel 16996273400\n/cns 700600973211961\n/placa ABC1234\n/cep 01153000\n/cnh 0004665540```')
      ]}).then(msg => {
        setTimeout(function () {
          msg.delete()
        }, 10000)
      })
    } catch (e) {
      console.log(String(e.stack).bgRed)
      return message.reply({embeds: [new MessageEmbed()
          .setColor(ee.wrongcolor)
          .setFooter(ee.footertext, ee.footericon)
          .setTitle(`UM ERRO OCORREU`)
          .setDescription(`\`\`\`${e.message ? String(e.message).substr(0, 2000) : String(e).substr(0, 2000)}\`\`\``)
      ]});
    }
  }
}