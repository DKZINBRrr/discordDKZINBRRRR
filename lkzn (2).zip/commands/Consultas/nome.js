const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const config = require("../../botconfig/config.json");
var ee = require("../../botconfig/embed.json");
const { GetUser, GetGlobalUser } = require("../../handlers/functions")
const request = require("request")
const fs = require("fs")
const settings = require("../../botconfig/settings.json");


const API = 'http://api.lkzn.tk/?token=6c11644f-8f5b-4f1f-88a3-225cb432312d&nomeLkzn='

module.exports = {
  name: "nome",
  category: "Consultas",
  cooldown: 5,
  usage: "!nome [NOME] [SOBRENOME]",
  description: "Consultar NOME [RECEITA]",
  minargs: 2,


  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    try {
      message.delete()
      let nome = args.slice(0).join(" ")
      console.log(nome)
      request(`${API}${nome}`, function (error, response, body) {
        var frame = JSON.parse(body.replace(/\:null/gi, "\:\"\"").replace(/\:true/gi, "\:\"\"").replace(/\:false/gi, "\:\"\"").replaceAll('undefined', 'NÃO ENCONTRADO'), function (key, value) { return (value === "") ? undefined : value })

        for (const valores in frame['msg']) {
          var mensagem = mensagem + '👥 **• NOME:** ' + '`' + frame['msg'][valores]['nome'] + '`' + '\n🔎 **• CPF:** ' + '`' + frame['msg'][valores]['cpf'] + '`' + '\n🌈 **• GENERO:** ' + '`' + frame['msg'][valores]['sexo'] + '`' + '\n📅 **• DATA DE NASCIMENTO:** ' + '`' + frame['msg'][valores]['nascimento'] + '`\n'
        }

        if (mensagem.length > 2048) {
          fs.writeFileSync("./commands/Consultas/consultas.txt", mensagem.replace("undefined", ""))
          message.channel.send({
            content: `${message.author}`,
            files: [
              "./commands/Consultas/consultas.txt",
            ],
          }).catch(error => {
            message.channel.send({
              content: ['**NOME NÃO ENCONTRADO!**'],
              ephemeral: true,
            }).then(msg => {
              setTimeout(function () {
                msg.delete()
              }, 10000)
            })
          }).then(msg => {
            setTimeout(function () {
              msg.delete()
            }, 10000)
          })
        }
        else {
          message.channel.send({
            content: mensagem.replace("undefined", ""),
          }).catch(error => {
            message.channel.send({
              content: ['**NOME NÃO ENCONTRADO!**'],
              ephemeral: true,
            }).then(msg => {
              setTimeout(function () {
                msg.delete()
              }, 10000)
            })
          }).then(msg => {
            setTimeout(function () {
              msg.delete()
            }, 10000)
          })
        }

      })


    } catch (e) {
      console.log(String(e.stack).bgRed)
      return message.reply({
        embeds: [new MessageEmbed()
          .setColor(ee.wrongcolor)
          .setTitle(`❌ Oops.. Espere ai!`)
          .setDescription(`Um erro ocorreu!`)
        ]
      });
    }
  }
}