const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const config = require("../../botconfig/config.json");
var ee = require("../../botconfig/embed.json");
const { GetUser, GetGlobalUser } = require("../../handlers/functions")
const request = require("request")
const settings = require("../../botconfig/settings.json");


const API = 'http://api.lkzn.tk/?token=6c11644f-8f5b-4f1f-88a3-225cb432312d&cpfData='

module.exports = {
  name: "cpf1",
  category: "Consultas",
  cooldown: 5,
  usage: ".cpf [CPF]",
  description: "Consultar CPF [DATASUS]",
  memberpermissions: [],
  requiredroles: [],
  alloweduserids: [],
  minargs: 1,
  maxargs: 1,
  minplusargs: 1,
  maxplusargs: 1,
  argsmissing_message: "",
  argstoomany_message: "",
  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    try {
      message.delete()
      request(`${API}${args[0]}`, function (error, response, body) {
        var frame = JSON.parse(body, function (key, value) { return (value === "") ? undefined : value })
        console.log(frame)
        const embed = new MessageEmbed()
          .setColor('#ff0000')
        if (frame['msg'] === null) return message.channel.send({ content: `${message.author}\n**CPF NÃO ENCONTRADO! TENTE DENOVO!**`}).then(msg => {
          setTimeout(function () {
            msg.delete()
          }, 10000)
        })
        if (frame['msg'].toString() === 'null') return message.channel.send({ content: `${message.author}\n**CPF NÃO ENCONTRADO! TENTE DENOVO!**`}).then(msg => {
          setTimeout(function () {
            msg.delete()
          }, 10000)
        })
      })

      request(`${API}${args[1]}`, function (error, response, body) {
        var frame = JSON.parse(body, function (key, value) { return (value === "") ? undefined : value })
        if (frame['msg'] === null) return message.channel.send({ content: `${message.author}\n**CPF NÃO ENCONTRADO! TENTE DENOVO!**`}).then(msg => {
          setTimeout(function () {
            msg.delete()
          }, 10000)
        })
        if (frame['msg'].toString() === 'null') return message.channel.send({ content: `${message.author}\n**CPF NÃO ENCONTRADO! TENTE DENOVO!**`}).then(msg => {
          setTimeout(function () {
            msg.delete()
          }, 10000)
        })
        var mensagem = '**❲ 👤 - DADOS CADASTRAIS ❳**'
          + '\n**• NOME:** ' + '`' + frame['msg']['nome'] + '`'
          + '\n** • CPF:** ' + '`' + frame['msg']['cpf'] + '`'
          + '\n** • CNS:** ' + '`' + frame['msg']['cns'] + '`'
          + '\n**• DATA DE NASCIMENTO:** ' + '`' + frame['msg']['nascimento'] + '`'

          + '\n\n**❲ 👨‍👧‍👦 - PARENTESCO ❳**'
          + '\n**• NOME DA MÃE:** ' + '`' + frame['msg']['mae'] + '`'
          + '\n**• NOME DO PAI:** ' + '`' + frame['msg']['pai'] + '`'

          + '\n\n**❲ 🏡 - ENDEREÇOS ❳**'
          + '\n**• BAIRRO: **' + '`' + frame['msg']['bairro'] + '`'
          + '\n**• CEP: **' + '`' + frame['msg']['cep'] + '`'
          + '\n**• LOGRADOURO: **' + '`' + frame['msg']['logradouro'] + '`'
          + '\n**• COMPLEMENTO: **' + '`' + frame['msg']['complemento'] + '`'
          + '\n**• NUMERO: **' + '`' + frame['msg']['numero'] + '`'
          + '\n\n**❲ 👶 - NASCIMENTO ❳**'
          + '\n**• MUNICIPIO DE NASCIMENTO:** ' + '`' + frame['msg']['municipioNasc'] + '`'

        const embed = new MessageEmbed()
          .setColor('#ff0000')

        setTimeout(function () {
          message.channel.send({
            content: mensagem.toString(),
          }).then(msg => {
            setTimeout(function () {
              msg.delete()
            }, 10000)
          })
        }, 500)
      })



    } catch (e) {
      console.log(String(e.stack).bgRed)
      return message.reply({
        embeds: [new MessageEmbed()
          .setColor(ee.wrongcolor)
          .setTitle(`❌ Oops.. Espere ai!`)
          .setDescription(`Um erro ocorreu!`)
        ]
      });
    }
  }
}