const Discord = require("discord.js");
const {MessageEmbed} = require("discord.js");
const config = require("../../botconfig/config.json")
var ee = require("../../botconfig/embed.json")
const settings = require("../../botconfig/settings.json");
const request = require("request")

const API = 'https://ipinfo.io'

module.exports = {
  name: "ip", 
  category: "Consultas", 
  cooldown: 5, 
  usage: "ip [IP]", 
  description: "Consultar IP", 
  minargs: 1, 
  maxargs: 1, 
  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    try {
      message.delete()
      request(`${API}/${args[0]}/json`, function (error, response, body) {
        var frame = JSON.parse(body.replace(/\:null/gi, "\:\"\"").replace(/\:true/gi, "\:\"\"").replace(/\:false/gi, "\:\"\"").replaceAll('undefined', 'NÃO ENCONTRADO'), function (key, value) { return (value === "") ? undefined : value })
        if (frame['status'].toString() === '404') return embed.setDescription(`**IP NÃO LOCALIZADO**`), interaction.reply({ embeds: [embed], ephemeral: true })
    })

      request(`${API}/${args[0]}/json`, function (error, response, body) {
        var frame = JSON.parse(body.replace(/\:null/gi, "\:\"\"").replace(/\:true/gi, "\:\"\"").replace(/\:false/gi, "\:\"\"").replaceAll('undefined', 'NÃO ENCONTRADO'), function (key, value) { return (value === "") ? undefined : value })
        var mensagem = `💻 **• IP:** ` + '`' + frame['ip'] + '`' +
            '\n📡** • PROVEDOR:** ' + '`' + frame['org'] + '`' + '\n🗺️ **• COORDENADAS:** ' + '`' + frame['loc'] + '`' + '\n🌎 **• PAIS:** ' + '`' + frame['country'] + '`' + '\n🚩 **• ESTADO:** ' + '`' + frame['region'] + '`' + '\n🚦 **• CIDADE:** ' + '`' + frame['city'] + '`'.replaceAll('null', 'NÃO ENCONTRADO')
        message.channel.send({
            content: mensagem,
        }).then(msg => {
          setTimeout(function () {
            msg.delete()
          }, 10000)
        })
      })
    } catch (e) {
      console.log(String(e.stack).bgRed)
      return message.reply({embeds: [new MessageEmbed()
          .setTitle(`API OFF`)
              ]});
    }
  }
}