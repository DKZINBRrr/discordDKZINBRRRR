const { MessageEmbed } = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const settings = require("../../botconfig/settings.json");
const request = require("request")

const API = ''
module.exports = {
  name: "chassi",
  category: "Consultas",
  cooldown: 5,
  usage: "chassi [CHASSI]",
  description: "Consultar chassi de Veiculo",
  minargs: 1,
  maxargs: 1,

  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    try {
      message.delete()
      request(`${API}${db.get(`alvoconsulta-${interaction.user.id}`)}`, function (error, response, body) {
        const frame = JSON.parse(body)
        var mensagem = '**❲ 🪧 - PLACA ❳**'
          + '\n**• PLACA:** ' + '`' + frame['msg']['msg']['placa'] + '`'
          + '\n** • MUNICIPIO EMP:** ' + '`' + frame['msg']['msg']['mun_emplacamento'] + '`'
          + '\n** • CÓDIGO MUNICIPIO:** ' + '`' + frame['msg']['msg']['mun_emplacamento_cod'] + '`'

          + '\n\n**❲ 🚗 - DADOS DO VEICULO ❳**'
          + '\n**• MODELO:** ' + '`' + frame['msg']['msg']['des_marca_modelo'] + '`'
          + '\n**• ANO:** ' + '`' + frame['msg']['msg']['ano_modelo'] + '`'
          + '\n**• COR:** ' + '`' + frame['msg']['msg']['cor_predominante'] + '`'
          + '\n**• CHASSI:** ' + '`' + frame['msg']['msg']['chassi'] + '`'
          + '\n**• RENAVAM:** ' + '`' + frame['msg']['msg']['renavam'] + '`'


          + '\n\n**❲ 👨‍💼 - PROPRIETÁRIO ❳**'
          + '\n**• NOME:** ' + '`' + frame['msg']['msg']['nome_proprietario'] + '`'
          + '\n**• CPF/CNPJ:** ' + '`' + frame['msg']['msg']['cpf_cnpj'] + '`'

          + '\n\n**❲ 💼 - EXTRA ❳**'
          + '\n**• Ultimo Pagamento IPVA: **' + '`' + 'SEM INFORMAÇÃO' + '`'
          + '\n**• DES CATEGORIA:** ' + '`' + frame['msg']['msg']['des_categoria'] + '`'
        if (frame['msg']['msg'].toString() === 'Registro nao Localizado!') {
          message.channel.send({
            content: '**CHASSI NÃO ENCONTRADA**',
          })
        }
        else {
          message.channel.send({
            content: `${message.author}\n` + mensagem,
          })
        }
      })
    } catch (e) {
      console.log(String(e.stack).bgRed)
      return message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`API OFF`)
        ]
      });
    }
  }
}
