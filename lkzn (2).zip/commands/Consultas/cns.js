const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const config = require("../../botconfig/config.json");
var ee = require("../../botconfig/embed.json");
const moment = require("moment")
const settings = require("../../botconfig/settings.json");

const API = ''

module.exports = {
  name: "cns",
  category: "Consultas",
  cooldown: 5,
  usage: ".cns [CNS]",
  description: "Consultar CPF [CNS]",
  memberpermissions: [],
  requiredroles: [],
  alloweduserids: [],
  minargs: 1,
  maxargs: 1,
  minplusargs: 1,
  maxplusargs: 1,
  argsmissing_message: "",
  argstoomany_message: "",
  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    try {
      message.delete()
      request(`${API}${args[0]}`, function (error, response, body) {
        var frame = JSON.parse(body, function (key, value) { return (value === "") ? undefined : value })
        const embed = new MessageEmbed()
          .setColor('#ff0000')
          if (frame['msg']['dados'][0] === null) return message.channel.send({ content: `${message.author}\n**CPF NÃO ENCONTRADO! TENTE DENOVO!**`}).then(msg => {
            setTimeout(function () {
              msg.delete()
            }, 10000)
          })
        if (frame['msg']['dados'].toString() === 'null') return message.channel.send({ content: `${message.author}\n**CPF NÃO ENCONTRADO! TENTE DENOVO!**`}).then(msg => {
          setTimeout(function () {
            msg.delete()
          }, 10000)
        })
      })

      request(`${API}${args[0]}`, function (error, response, body) {
        var frame = JSON.parse(body, function (key, value) { return (value === "") ? undefined : value })
        var mensagem = '**❲ 👤 - DADOS CADASTRAIS ❳**'
          + '\n**• NOME:** ' + '`' + frame['msg']['dados'][0]['nome'] + '`'
          + '\n** • CPF:** ' + '`' + frame['msg']['dados'][0]['cpf'] + '`'
          + '\n** • CNS:** ' + '`' + frame['msg']['dados'][0]['cns'] + '`'
          + '\n**• DATA DE NASCIMENTO:** ' + '`' + frame['msg']['dados'][0]['dataNascimento'] + '`'
          + '\n**• SEXO:** ' + '`' + frame['msg']['dados'][0]['sexo'] + '`'
          + '\n**• COR:** ' + '`' + frame['msg']['dados'][0]['racaCor']['nome'] + '`'

          + '\n\n**❲ 👨‍👧‍👦 - PARENTESCO ❳**'
          + '\n**• NOME DA MÃE:** ' + '`' + frame['msg']['dados'][0]['nomeMae'] + '`'
          + '\n**• NOME DO PAI:** ' + '`' + frame['msg']['dados'][0]['nomePai'] + '`'

          + '\n\n**❲ 🏡 - ENDEREÇOS ❳**'
          + '\n**• ESTADO: **' + '`' + frame['msg']['dados'][0]['endereco']['municipio']['uf']['nome'] + ' - ' + frame['msg']['dados'][0]['endereco']['municipio']['uf']['sigla'] + '`'
          + '\n**• MUNICIPIO: **' + '`' + frame['msg']['dados'][0]['endereco']['municipio']['nome'] + '`'
          + '\n**• BAIRRO: **' + '`' + frame['msg']['dados'][0]['endereco']['bairro'] + '`'
          + '\n**• CEP: **' + '`' + frame['msg']['dados'][0]['endereco']['cep'] + '`'
          + '\n**• LOGRADOURO: **' + '`' + frame['msg']['dados'][0]['endereco']['logradouro'] + '`'
          + '\n**• COMPLEMENTO: **' + '`' + frame['msg']['dados'][0]['endereco']['complemento'] + '`'
          + '\n**• NUMERO: **' + '`' + frame['msg']['dados'][0]['endereco']['numero'] + '`'
          + '\n\n**❲ 📱 - CONTATOS ❳**'
          + '\n**• EMAIL: **' + '`' + frame['msg']['dados'][0]['email'] + '`'
          + '\n**• CELULAR: **' + '`' + frame['msg']['dados'][0]['telefoneCelular'] + '`'
          + '\n**• TELEFONE: **' + '`' + frame['msg']['dados'][0]['telefoneContato'] + '`'
          + '\n**• RESIDENCIAL: **' + '`' + frame['msg']['dados'][0]['telefoneResidencial'] + '`'
          + '\n\n**❲ 👶 - NASCIMENTO ❳**'


        if (frame['msg']['dados'][0]['municipioNascimento'] != null) {
          mensagem = mensagem + '\n**• ESTADO DE NASCIMENTO: **' + '`' + frame['msg']['dados'][0]['municipioNascimento']['uf']['nome'] + ' - ' + frame['msg']['dados'][0]['municipioNascimento']['uf']['sigla'] + '`'
            + '\n**• MUNICIPIO DE NASCIMENTO:** ' + '`' + frame['msg']['dados'][0]['municipioNascimento']['nome'] + '`'
        }
        else {
          mensagem = mensagem + '\n**• ESTADO DE NASCIMENTO: **' + '`' + 'NÃO ENCONTRADO' + '`'
            + '\n**• MUNICIPIO DE NASCIMENTO:** ' + '`' + 'NÃO ENCONTRADO' + '`'
        }

        if (frame['msg']['dados'][0]['obito'] != 'false') {
          mensagem = mensagem + '\n\n**❲ ✝️ - ESTADO ❳**'
            + '\n**ÓBITO:** ' + '`' + frame['msg']['dados'][0]['obito'] + '`'
            + '\n**DATA ÓBITO:** ' + '`' + frame['msg']['dados'][0]['dataObito'] + '`'
        }

        setTimeout(function () {
          message.channel.send({content: `${mensagem.toString()}`}).then(msg => {
            setTimeout(function() {
              msg.delete()
            })
          })
        }, 500)
      })



    } catch (e) {
      console.log(String(e.stack).bgRed)
      return message.reply({
        embeds: [new MessageEmbed()
          .setColor(ee.wrongcolor)
          .setTitle(`❌ Oops.. Espere ai!`)
          .setDescription(`Um erro ocorreu!`)
        ]
      });
    }
  }
}