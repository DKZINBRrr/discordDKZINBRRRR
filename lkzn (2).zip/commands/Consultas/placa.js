const Discord = require("discord.js");
const {MessageEmbed} = require("discord.js");
const config = require("../../botconfig/config.json");
var ee = require("../../botconfig/embed.json");
const { GetUser } = require("../../handlers/functions")
const settings = require("../../botconfig/settings.json");
const request = require("request")

const API = 'http://api.lkzn.tk/?token=6c11644f-8f5b-4f1f-88a3-225cb432312d&placaLkzn='

module.exports = {
  name: "placa", 
  category: "Consultas", 
  cooldown: 5, 
  usage: "placa [PLACA]",
  description: "Consultar placa", 
  minargs: 0, 
  maxargs: 0, 
  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    try {   
      message.delete()
      request(`${API}${args[0]}`, function (error, response, body) {
        const frame = JSON.parse(body)
        var mensagem = '**❲ 🪧 - PLACA ❳**'
        + '\n**• PLACA:** ' + '`' + frame['msg']['placa'] + '`'
        + '\n** • MUNICIPIO EMP:** ' + '`' + frame['msg']['mun_emplacamento'] + '`'
        + '\n** • CÓDIGO MUNICIPIO:** ' + '`' + frame['msg']['mun_emplacamento_cod'] + '`'

        + '\n\n**❲ 🚗 - DADOS DO VEICULO ❳**'
        + '\n**• MODELO:** ' + '`' + frame['msg']['des_marca_modelo'] + '`'
        + '\n**• ANO:** ' + '`' + frame['msg']['ano_modelo'] + '`'
        + '\n**• COR:** ' + '`' + frame['msg']['cor_predominante'] + '`'
        + '\n**• CHASSI:** ' + '`' + frame['msg']['chassi'] + '`'
        + '\n**• RENAVAM:** ' + '`' + frame['msg']['renavam'] + '`'


        + '\n\n**❲ 👨‍💼 - PROPRIETÁRIO ❳**'
        + '\n**• NOME:** ' + '`' + frame['msg']['nome_proprietario'] + '`'
        + '\n**• CPF/CNPJ:** ' + '`' + frame['msg']['cpf_cnpj'] + '`'

        + '\n\n**❲ 💼 - EXTRA ❳**'
        + '\n**• Ultimo Pagamento IPVA: **' + '`' + 'SEM INFORMAÇÃO' + '`'
        + '\n**• DES CATEGORIA:** ' + '`' + frame['msg']['des_categoria'] + '`'
        if(frame['msg'].toString() === 'Registro nao Localizado!') {
        message.channel.send({
            content: '**PLACA NÃO ENCONTRADA**',
        })
        }
        else {
        message.channel.send({
            content: mensagem,
        })
        }
      })
      
    } catch (e) {
      console.log(String(e.stack).bgRed)
      return message.reply({embeds: [new MessageEmbed()
          .setColor(ee.wrongcolor)
          .setFooter(ee.footertext, ee.footericon)
          .setTitle(`❌ ERROR | An error occurred`)
          .setDescription(`\`\`\`${e.message ? String(e.message).substr(0, 2000) : String(e).substr(0, 2000)}\`\`\``)
      ]});
    }
  }
}
/**
 * @INFO
 * Bot Coded by Tomato#6966 | https://github.com/Tomato6966/discord-js-lavalink-Music-Bot-erela-js
 * @INFO
 * Work for Milrato Development | https://milrato.eu
 * @INFO
 * Please mention Him / Milrato Development, when using this Code!
 * @INFO
 */
