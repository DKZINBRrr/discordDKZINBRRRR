const Discord = require("discord.js");
const {MessageEmbed} = require("discord.js");
const config = require("../../botconfig/config.json");
var ee = require("../../botconfig/embed.json");
const { GetUser, GetGlobalUser } = require("../../handlers/functions")
const settings = require("../../botconfig/settings.json");
const request = require("request")

var mensagem = ''
module.exports = {
  name: "cpf3", //the command name for execution & for helpcmd [OPTIONAL]
  category: "Consultas", //the command category for helpcmd [OPTIONAL]
  cooldown: 5, //the command cooldown for execution & for helpcmd [OPTIONAL]
  usage: "cpf3 [CPF]", //the command usage for helpcmd [OPTIONAL]
  description: "Puxar dados pelo CPF3", //the command description for helpcmd [OPTIONAL]
  memberpermissions: [], //Only allow members with specific Permissions to execute a Commmand [OPTIONAL]
  requiredroles: [], //Only allow specific Users with a Role to execute a Command [OPTIONAL]
  alloweduserids: [], //Only allow specific Users to execute a Command [OPTIONAL]
  minargs: 1, // minimum args for the message, 0 == none [OPTIONAL]
  maxargs: 1, // maximum args for the message, 0 == none [OPTIONAL]
  minplusargs: 1, // minimum args for the message, splitted with "++" , 0 == none [OPTIONAL]
  maxplusargs: 1, // maximum args for the message, splitted with "++" , 0 == none [OPTIONAL]
  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    console.log(args[0])
    const API = `https://consumer.bvsnet.com.br/dadoscadastrais/json/v02?usuario=20005980881&senha=E1V2&cpf=${args[0]}&params=CC,LO,QA`
    try {
      message.delete()
      request(API, function (error, response, body) {
        //         fs.appendFileSync("./metodos/fivexconsultas.txt", '')
        const frame = JSON.parse(body)
        if (frame['codigo'] === 500) return mensagem = (`${message.author}\n**CPF NÃO ENCONTRADO! TENTE DENOVO!**`), message.channel.send({content: `${mensagem}`})
        console.log(frame)
        if (frame['cadastroBasico']) {
            var mensagem = '**❲ 👤 - DADOS BASICO ❳**'
                + '\n**• NOME:** ' + '`' + frame['cadastroBasico']['nome'] + '`'
                + '\n** • CPF:** ' + '`' + frame['cadastroBasico']['cpf'] + '`'
                + '\n**• DATA DE NASCIMENTO:** ' + '`' + frame['cadastroBasico']['dataNascimento'] + '`'
                + '\n**• SITUAÇÃO CPF:** ' + '`' + frame['cadastroBasico']['situacaoCPF'] + '`'
                + '\n**• Nome da Mãe:** ' + '`' + frame['cadastroBasico']['nomeMae'] + '`'
            message.channel.send({content: `${mensagem}`})
        }

        var mensagem = '**❲ 👤 - DADOS CADASTRAIS ❳**'
            + '\n**• NOME:** ' + '`' + frame['cadastroCompleto']['nome'] + '`'
            + '\n** • CPF:** ' + '`' + frame['cadastroCompleto']['cpf'] + '`'
            + '\n**• RG:** ' + '`' + 'SEM INFORMAÇÃO' + '`'
            + '\n**• DATA DE NASCIMENTO:** ' + '`' + frame['cadastroCompleto']['dataNascimento'] + '`'
            + '\n**• NACIONALIDADE:** ' + '`' + 'Brasileiro' + '`'
            //    + '\n**• TITULO DE ELEITOR:** ' + '`' + frame['cadastroCompleto'][''] + '`'
            + '\n**• SEXO:** ' + '`' + frame['cadastroCompleto']['sexo'] + '`'
            + '\n**• SIGNO:** ' + '`' + frame['cadastroCompleto']['signo'] + '`'

            + '\n\n**❲ 💼 - PESSOAL ❳**'
            + '\n**• GRAU INSTRUÇÃO:** ' + '`' + frame['cadastroCompleto']['grauInstrucao'] + '`'
            //  + '\n** • ESTADO CIVIL:** ' + '`' + frame['cadastroCompleto'][''] + '`'
            + '\n** • DATA ATUALIZAÇÃO CPF:** ' + '`' + frame['cadastroCompleto']['dataAtualizacaoCPF'] + '`'
            + '\n** • REGIÃO ORIGEM CPF:** ' + '`' + frame['cadastroCompleto']['regiaoOrigemCPF'] + '`'

            + '\n\n**❲ 👨‍👧‍👦 - PAIS ❳**'
            + '\n**• NOME DA MÃE:** ' + '`' + frame['cadastroCompleto']['nomeMae'] + '`'
           
            var mensagem = mensagem + '\n\n**❲ 👨‍👧 - PARENTESCO ❳**'


        if (frame['qualificacao']['pessoasRelacionada']) {
            for (const parentes of frame['qualificacao']['pessoasRelacionada']) {
                var mensagem = mensagem
                    + '\n**• NOME:** ' + '`' + parentes['nome'] + '`'
                    + '\n**• CPF:** ' + '`' + parentes['cpf'] + '`'
                    + '\n**• GRAU:** ' + '`' + parentes['grauParentesco'] + '`\n'
            }
        }
        var mensagem = mensagem + '\n\n**❲ 📱 - TELEFONES ❳**'
        if (frame['qualificacao']['telefones']) {
            for (const telefone of frame['localizacao']['telefones']) {
                var mensagem = mensagem
                    + '\n**• NÚMERO:** ' + '`' + `(${telefone['ddd']}) ` + `${telefone['numero']}` + '`'
                    + '\n**• TIPO:** ' + '`' + `${telefone['tipo']}` + '`'
            }
        }


        var mensagem = mensagem + '\n\n**❲ 📩 - EMAIL ❳**'


        if (frame['localizacao'] && frame['localizacao']['emails']) {
            for (const email in frame['localizacao']['emails']) {
                var mensagem = mensagem
                    + '\n**• EMAIL:** ' + '`' + `${frame['localizacao']['emails'][email]}` + '`'
            }
        }


        var mensagem = mensagem + '\n\n**❲ 🏡 - ENDEREÇOS ❳**'

        if (frame['localizacao'] && frame['localizacao']['enderecos']) {
            for (const endereco of frame['localizacao']['enderecos']) {
                var mensagem = mensagem
                    + '\n**• TIPO:** ' + '`' + `${endereco['tipoLogradouro']}` + '`'
                    + '\n**• LOGRADOURO:** ' + '`' + `${endereco['logradouro']}` + '`'
                    + '\n**• NÚMERO:** ' + '`' + `${endereco['numero']}` + '`'
                    + '\n**• BAIRRO:** ' + '`' + `${endereco['bairro']}` + '`'
                    + '\n**• CIDADE:** ' + '`' + `${endereco['cidade']}` + '`'
                    + '\n**• UF:** ' + '`' + `${endereco['uf']}` + '`'
                    + '\n**• CEP:** ' + '`' + `${endereco['cep']}` + '`\n'
            }
        }
        message.channel.send({
          content: `${message.author}\n`+mensagem.toString(),
        }).then(msg => {
          setTimeout(function () {
            msg.delete()
          }, 10000)
        })
      })



    } catch (e) {
      console.log(String(e.stack).bgRed)
      return message.channel.send({
        embeds: [new MessageEmbed()
          .setColor(ee.wrongcolor)
          .setTitle(`❌ Oops.. Espere ai!`)
          .setDescription(`Um erro ocorreu!`)
        ]
      });
    }
  }
}