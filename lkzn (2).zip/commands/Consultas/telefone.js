const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const config = require("../../botconfig/config.json")
var ee = require("../../botconfig/embed.json")
const settings = require("../../botconfig/settings.json");
const request = require("request")


module.exports = {
  name: "telefone", //the command name for execution & for helpcmd [OPTIONAL]
  category: "Consultas", //the command category for helpcmd [OPTIONAL]
  aliases: ["tel"], //the command aliases for helpcmd [OPTIONAL]
  cooldown: 5, //the command cooldown for execution & for helpcmd [OPTIONAL]
  usage: "telefone [NÚMERO]", //the command usage for helpcmd [OPTIONAL]
  description: "Shows the Amount of Members in DETAIL", //the command description for helpcmd [OPTIONAL]
  minargs: 0, // minimum args for the message, 0 == none [OPTIONAL]
  maxargs: 0, // maximum args for the message, 0 == none [OPTIONAL]
  minplusargs: 0, // minimum args for the message, splitted with "++" , 0 == none [OPTIONAL]
  maxplusargs: 0, // maximum args for the message, splitted with "++" , 0 == none [OPTIONAL]
  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    try {
      message.delete()
      const embed = new MessageEmbed()
        .setColor('#ff0000')
      const API = 'http://api.lkzn.tk/?token=6c11644f-8f5b-4f1f-88a3-225cb432312d&telDb='

      request(`${API}${args[0]}`, function (error, response, body) {
        var frame = JSON.parse(body.replace(/\:null/gi, "\:\"\"").replace(/\:true/gi, "\:\"\"").replace(/\:false/gi, "\:\"\"").replaceAll('undefined', 'NÃO ENCONTRADO'), function (key, value) { return (value === "") ? undefined : value })
        if (frame['msg'][0].length === 1) return message.channel.send({ content: '**TELEFONE NÃO ENCONTRADO**', ephemeral: true }).then(msg => {
          setTimeout(function () {
            msg.delete()
          }, 10000)
        })
        else {
          const API = 'http://api.lkzn.tk/?token=6c11644f-8f5b-4f1f-88a3-225cb432312d&telDb='
          request(`${API}${args[0]}`, function (error, response, body) {
            var frame = JSON.parse(body.replace(/\:null/gi, "\:\"\"").replace(/\:true/gi, "\:\"\"").replace(/\:false/gi, "\:\"\"").replaceAll(undefined, 'NÃO ENCONTRADO'), function (key, value) { return (value === "") ? undefined : value })
            var mensagem = '👤 ➠ **DADOS CADASTRAIS**\n**📞 • TELEFONE:** ' + '`' + `${frame['msg'][0]['telefone']}` + '`' + '\n👥 ** • NOME:** ' + '`' + `${frame['msg'][0]['nome']}` + '`' + '\n🔎 ** • CPF/CNPJ:** ' + '`' + `${frame['msg'][0]['cpf_cnpj']}` + '`' + '\n\n**🏡 ➠ ENDEREÇOS**\n🏠 ** • LOGRADOURO:** ' + '`' + `${frame['msg'][0]['logradouro']}` + '`' + '\n🪧 ** • NÚMERO:** ' + '`' + `${frame['msg'][0]['numero']}` + '`' + '\n🚦 ** • BAIRRO:** ' + '`' + `${frame['msg'][0]['bairro']}` + '`' + '\n🚩 ** • ESTADO:** ' + '`' + `${frame['msg'][0]['uf']}` + '`' + '\n🌎 ** • CEP:** ' + '`' + `${frame['msg'][0]['cep']}` + '`'.replaceAll('null', 'NÃO ENCONTRADO').replaceAll('undefined', 'NÃO ENCONTRADO')
            message.channel.send({
              content: mensagem+`\n${message.author}`,
            }).then(msg => {
              setTimeout(function () {
                msg.delete()
              }, 10000)
            })

          })
        }
        return;
      })


    } catch (e) {
      console.log(String(e.stack).bgRed)
      return message.reply({
        embeds: [new MessageEmbed()
          .setColor(ee.wrongcolor)
          .setFooter(ee.footertext, ee.footericon)
          .setTitle(`❌ ERROR | An error occurred`)
          .setDescription(`\`\`\`${e.message ? String(e.message).substr(0, 2000) : String(e).substr(0, 2000)}\`\`\``)
        ]
      });
    }
  }
}

