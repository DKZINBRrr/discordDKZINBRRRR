const { MessageEmbed } = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const settings = require("../../botconfig/settings.json");
module.exports = {
  name: "cnh",
  category: "Consultas", 
  cooldown: 5, 
  usage: "ping", 
  description: "Consultar CNH", 
  minargs: 1, 
  maxargs: 1,
  run: async (client, message, args, plusArgs, cmdUser, text, prefix) => {
    try{
     


    } catch (e) {
        console.log(String(e.stack).bgRed)
        return message.reply({embeds: [new MessageEmbed()
            .setTitle(`API OFF`)
        ]});
    }
  }
}